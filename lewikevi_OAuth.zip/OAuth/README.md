Basic template for GAE webapp2
==========

1. Install Git Flow: http://danielkummer.github.io/git-flow-cheatsheet/
2. Clone the project
3. Do ```git flow init``` to set up git flow
4. Do NOT do any development on the master branch
5. Use git flow features to develop new things (see the Git Flow Cheatsheet above)