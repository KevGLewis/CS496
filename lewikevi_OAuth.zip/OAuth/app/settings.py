"""
    App settings file
"""

ADMINS = [
    "your@email.com",
    "another@email.com"
]